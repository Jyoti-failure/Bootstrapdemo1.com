function f1(value) {
    document.getElementById('display').value += value;
}

function fun() {
    document.getElementById('display').value = '';
}

function calculate() {
    let res = document.getElementById('display').value;
    let result = eval(res);
    document.getElementById('display').value = result;
}
